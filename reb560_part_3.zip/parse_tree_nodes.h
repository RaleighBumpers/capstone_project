//*****************************************************************************
// purpose: node classes used while building a parse tree for
//              the arithmetic expression
// version: Spring 2022
//  author: Raleigh Bumpers reb560
//*****************************************************************************

#ifndef PARSE_TREE_NODES_H
#define PARSE_TREE_NODES_H

#include <iostream>
#include <vector>
#include <string>
#include "lexer.h"

using namespace std;

// Forward declaration of nodes
class ExpressionNode;
class SimpleExpressionNode; 
class ProgNode;
class BlockNode;
class StateNode;
class AssignNode;
class CompNode;
class IfNode;
class WhileNode;
class ReadNode;
class WriteNode;
class FactorNode;
class IdNode;
class IntLitNode;
class FloatLitNode;
class NestedExprNode;
class TermNode;
class StringLitNode;
class NotNode;
class MinusNode;

// Forward declaration of operator<< for Nodes
ostream& operator<<(ostream& os, ExpressionNode& en);
ostream& operator<<(ostream& os, SimpleExpressionNode& sn);
ostream& operator<<(ostream& os, ProgNode& pn);
ostream& operator<<(ostream& os, BlockNode& bn);
ostream& operator<<(ostream& os, StateNode& node);
ostream& operator<<(ostream& os, AssignNode& node);
ostream& operator<<(ostream& os, CompNode& node);
ostream& operator<<(ostream& os, IfNode& en);
ostream& operator<<(ostream& os, WhileNode& en);
ostream& operator<<(ostream& os, ReadNode& en);
ostream& operator<<(ostream& os, WriteNode& en);
ostream& operator<<(ostream& os, FactorNode& en);
ostream& operator<<(ostream& os, IdNode& en);
ostream& operator<<(ostream& os, IntLitNode& en);
ostream& operator<<(ostream& os, FloatLitNode& en);
ostream& operator<<(ostream& os, NestedExprNode& nn);
ostream& operator<<(ostream& os, TermNode& tn);
ostream &operator<<(ostream &os, StringLitNode &node);
ostream &operator<<(ostream &os, NotNode &en);
ostream &operator<<(ostream &os, MinusNode &en);
//*****************************************************************************
//table to convert token numerals to symbol lexemes
string token_to_string(int token)
{
    switch (token)
    {
    case TOK_PLUS:
        return "+";
    case TOK_MINUS:
        return "-";
    case TOK_MULTIPLY:
        return " *";
    case TOK_DIVIDE:
        return " /";
    case TOK_ASSIGN:
        return " := ";
    case TOK_EQUALTO:
        return " =";
    case TOK_LESSTHAN:
        return " <";
    case TOK_GREATERTHAN:
        return " >";
    case TOK_NOTEQUALTO:
        return " <>";
    case TOK_MOD:
        return " MOD";
    case TOK_NOT:
        return " NOT";
    case TOK_OR:
        return " OR";
    case TOK_AND:
        return " AND";
    default:
        return " UNKNOWN TOKEN";
    }
}
//*****************************************************************************
//Program Node (program function)
class ProgNode 
{
	public:
		//set string name pointer to null
		string *name = nullptr;
		//set block pointer to null
		BlockNode *block = nullptr;

		//call ProgNode
		ProgNode(string id, BlockNode *blk);
		//Destruct ProgNode
		~ProgNode();
};

// Uses double dispatch to call the overloaded method printTo in the 
ostream& operator<<(ostream& os, ProgNode& pn) {
	//print program name and the user entered name of the program
	os << "Program Name " << *(pn.name) << endl;
	//print block
	os << *(pn.block) << endl;
	//return
	return os;
}

ProgNode::ProgNode(string id, BlockNode *blk) {
	//set name equal to a new identifier string
	name = new string(id);
	//set block equal to 'blk'
	block = blk;
}


//*****************************************************************************
//Block Node (block function)
class BlockNode 
{
	public:
		//create a vector of string pointers
		vector<string *> *var;
		//create a vector of StateNode pointers
		vector<StateNode *> *statements;
		//call BlockNode
		BlockNode();
		
		//Destruct BlockNode
		~BlockNode();
};

// Uses double dispatch to call the overloaded method printTo in the 
ostream& operator<<(ostream& os, BlockNode& bn) {
	//set length equal to the statements in the the vector in block
	int length = bn.statements->size();
	//for loop print block statements
	for(int i = 0; i < length; ++i)
	{
		//print out block statements
		os << *(bn.statements->at(i));
	}
	//return
	return os;
}

BlockNode::BlockNode() {
	//set var to a new vector of string pointers
	var = new vector<string *>;
	//set statemaents equal to a new vector of StateNode pointers
	statements = new vector<StateNode *>;
}



//*****************************************************************************
//Statement Node (statement function)
class StateNode
{
	public:
		//virtual method, makes the class abstract
		virtual void printTo(ostream &os) = 0;
		//virtual destructor lets subcalss destructors be called
		virtual ~StateNode();
};

ostream &operator<<(ostream &os, StateNode &node)
{
	//print StateNode
    node.printTo(os);
	//return
    return os;
}
//destruct StateNode
StateNode::~StateNode() {}
//*****************************************************************************
// Abstract class. Base class for IdNode, IntLitNode, NestedExprNode.
class FactorNode {
public:
    virtual void printTo(ostream &os) = 0; // pure virtual method, makes the class Abstract
    virtual ~FactorNode(); // labeling the destructor as virtual allows 
	                       // the subclass destructors to be called
};

//*****************************************************************************
//Compound Statement Node (compound_statement factor)
class CompNode: public StateNode
{
	public:
		//name pointer set to null
		string *name = nullptr;
		//firstStatement pointer set to null
		StateNode *firstStatement = nullptr;
		//create a vector of TStaeNode pointers
		vector<StateNode *> *Statements;
		//call CompNode
		CompNode();

		//destruct CompNode
		~CompNode();
		//printTo method
		void printTo(ostream &os);
};

void CompNode::printTo(ostream &os)
{
	//print the Begin Compund Statement message
    os << "Begin Compound Statement" << endl;
	//print the firstStatement pointer
    os << *firstStatement << endl;
	//set length equal to Statements in the vector
    int length = Statements->size();
	//for loop
    for (int i = 0; i < length; ++i)
    {
		//print Statements at i
        os << *(Statements->at(i)) << endl;
    }
	//print the end compound statement message
    os << "End Compound Statement" << "";
}

CompNode::CompNode() {
	//set name equal to a new string
	name = new string();
	//set Statements to the vector node of StateNode pointers
	Statements = new vector<StateNode *>;
}

CompNode::~CompNode()
{
	//print out the deleting compund node message
    cout << "Deleting a compoundNode" << endl;
	//delete firstStatement
    delete firstStatement;
	//set equal to null
    firstStatement = nullptr;
	//set length equal to Statements in vector
    int length = Statements->size();
	//for loop
    for (int i = 0; i < length; ++i)
    {
		//delete Statements
        delete Statements->at(i);
		//set Statements to null
        Statements->at(i) = nullptr;
    }
}


//*****************************************************************************
class ReadNode : public StateNode
{
	public:
		//set name pointer equal to null
		string* name = nullptr;
		//call ReadNode
		ReadNode();

		//call ReadNode passing an id	
		ReadNode(string id);
		//call ReadNode passing a node
		ReadNode(ReadNode* node);
		//printTo
		void printTo(ostream &os);
		//destruct ReadNode
		~ReadNode();
};

void ReadNode::printTo(ostream& os) {
	//print Read Value followed by the name in read
	os << "Read Value " << *name;
}

ReadNode::ReadNode()
{
	//set name equal to string function
    name = new string();
}

ReadNode::~ReadNode()
{
	//print deleting a read node
    cout << "Deleting a readNode" << endl;
	//delete name
    delete name;
}

//*****************************************************************************
// class TermNode (term function)
class TermNode {
public:
	//set name pointer equal to null
	string *name = nullptr;
	//set FirstFactor pointer equal to null
    FactorNode* FirstFactor = nullptr;
	//declare a vector as restFactorOps
    vector<int> restFactorOps;
	//make the vector hold FactorNode pointers
    vector<FactorNode  *> restFactors;

	//call TermNode
	TermNode();
	//Destruct TerMNode
    ~TermNode();
};

TermNode::TermNode() {
	//set name equal to string function
	name = new string();
}

ostream& operator<<(ostream& os, TermNode& tn) {
	//print term
	os << " term(";
	//print firstFactor
	os << *(tn.FirstFactor);

	//set length to the size of restFactorOps
	int length = tn.restFactorOps.size();
	//for loop
	for (int i = 0; i < length; ++i) {
		//set op
		int op = tn.restFactorOps[i];
		//print the token
		os << token_to_string(op);
		//print tn.restFactors pointer
		os << *(tn.restFactors[i]);
	}
	//print closing parenthese
	os << " ) ";
	//return
	return os;
}

TermNode::~TermNode() {
	//print deleting termNode
	cout << "Deleting a termNode" << endl;
	//delete name
	delete name;
	//delete FirstFactor
	delete FirstFactor;
	//set FirstFactor equal to null
	FirstFactor = nullptr;

	//set length to the size of restFactors
	int length = restFactors.size();
	//for loop
	for (int i = 0; i < length; ++i) {
		//delete restFactors
		delete restFactors[i];
		//set restFactors to null
		restFactors[i] = nullptr;
	}
}
//*****************************************************************************
// class SimpleExpressionNode (simple_expr function)
class SimpleExpressionNode {
public:
	//set name equal to null
	string *name = nullptr;
	//set firstTerm equal to null
	TermNode *firstTerm = nullptr;
	//createt a vector of TermNode pointers
	vector<TermNode *> terms;
	//call the vector termOps
	vector<int> termOps;

	//call simple expression node
	SimpleExpressionNode();
	//destruct simple expression node
	~SimpleExpressionNode();
};

SimpleExpressionNode::SimpleExpressionNode() {
	//set name equal to string function
	name = new string();
	//set firstTerm equal to TermNode
	firstTerm = new TermNode;
}

ostream &operator<<(ostream &os, SimpleExpressionNode &sn)
{
	//print simple expression
    os << " simple_expression(";
	//print firstTerm pointer
    os << *(sn.firstTerm);
	//set length to size of sn.terms
    int length = sn.terms.size();
	//for loop
    for (int i = 0; i < length; ++i)
    {
		//set op
        int op = sn.termOps[i];
		//print the correct token
        os << token_to_string(op);
		//print sn.terms 
        os << *(sn.terms[i]);
    }
	//print closing parenthese
    os << ")";
	//return
    return os;
}

SimpleExpressionNode::~SimpleExpressionNode()

{
	//print deleting simple expression node
    cout << "Deleting a simpleExpressionNode" << endl;
	//delete name
    delete name;
	//delete firstTerm
    delete firstTerm;
	//set firstTerm equal to null
    firstTerm = nullptr;
	//set length equal to size of terms vector
    int length = terms.size();
	//for loop
    for (int i = 0; i < length; ++i)
    {
		//delete terms
        delete terms[i];
		//set terms to null
        terms[i] = nullptr;
    }
}
//*****************************************************************************
// class ExpressionNode (Expression Node)
class ExpressionNode {
public:
//set name to null
	string *name = nullptr;
	//set firstSimpleExpression to null
	SimpleExpressionNode *firstSimpleExpression = nullptr;
	//create vector called restSimpleExpressions
	vector<int> restSimpleExpressionOps;
	//make the vector full of SimpleExpressionNode pointers
	vector<SimpleExpressionNode *> restSimpleExpressions;

	//call expression node
	ExpressionNode();
	//destruct simple expression node
    ~ExpressionNode();
};

ostream& operator<<(ostream& os, ExpressionNode& en) {
	//print expression
	os << "expression(";
	//print firstSimpleExpression pointer
	os << *(en.firstSimpleExpression);
	//set length to the size of restSimpleExpressions vector
	int length = en.restSimpleExpressions.size();
	//for loop
	for (int i = 0; i < length; ++i) {
		//set op
		int op = en.restSimpleExpressionOps[i];
        //print out correct token
        os << token_to_string(op);
        //print restSimpleExpressions pointer
        os << *(en.restSimpleExpressions[i]);
	}
	//print closing parenthese
	os << " )" << "";
	//return
	return os;
}

ExpressionNode::ExpressionNode() {
	//set name equal to string function
	name = new string();
	//set firstSimpleExpression to SimpleExpressionNode
	firstSimpleExpression = new SimpleExpressionNode;
}

ExpressionNode::~ExpressionNode() {
	//print deleting simple expresson node
	cout << "Deleting an expressionNode" << endl;
	//delete name
	delete name;
	//delete firstSimpleExpression
	delete firstSimpleExpression;
	//set firstSimpleExpression to null
	firstSimpleExpression = nullptr;

	//set length to the size of restSimpleExpressions vector
	int length = restSimpleExpressions.size();
	//for loop
	for (int i = 0; i < length; ++i) {
		//delete restSimpleExpression
		delete restSimpleExpressions[i];
		//set restSimpleExpressions to null
		restSimpleExpressions[i] = nullptr;
	}
}
//*****************************************************************************
// class NestedExprNode (Nested Expression Node)
class NestedExprNode : public FactorNode {
public:
	//set expressPtr pointer equal to null
    ExpressionNode *expressPtr = nullptr;

	//call nested expression node
    NestedExprNode(ExpressionNode* en);
	//Destruct nested expression node
	~NestedExprNode();
	//printTo
    void printTo(ostream & os);
};

NestedExprNode::NestedExprNode(ExpressionNode *en) {
	//set expressPtr equal to en pointer
	expressPtr = en;
}

void NestedExprNode::printTo(ostream& os) {
	//print nested expression followed by the expression by printing expressPtr pointer
	os << " nested_expression( " << *expressPtr << " )";
}

NestedExprNode::~NestedExprNode()
{
	//print delete a factor node
	cout << "Deleting a factorNode" << endl;
	//delete expressPtr
    delete expressPtr;
	//set expressPtr equal to null
    expressPtr = nullptr;
}
//*****************************************************************************
class AssignNode: public StateNode
{
	public:
		//set name pointer equal to null
		string *name = nullptr;
		//set assignExpr pointer equal to null
		ExpressionNode *assignExpr = nullptr;
		//set AOp to its token number
		int AOp = 3004;
		//call AssignNode
		AssignNode();

		//Destruct AssignNode
		~AssignNode();
		//printTo
		void printTo(ostream &os);
};

void AssignNode::printTo(ostream& os) {
	//print assignment followed by the assignment identifier and the := symbol and the assignExpr pointer
	os << "Assignment " << *name << token_to_string(AOp) <<  *assignExpr << "";

}

AssignNode::AssignNode() {
	//set name equal to string function
	name = new string();
	//set assignExpr equal to ExpressionNode
	assignExpr = new ExpressionNode;
}

AssignNode::~AssignNode()
{
	//print delete assignment node
    cout << "Deleting an assignmentNode" << endl;
	//delete name
    delete name;
	//delete assignExpr
    delete assignExpr;
	//set assignExpr to null
    assignExpr = nullptr;
}
//*****************************************************************************
class IfNode: public StateNode
{
	public:
		//set name pointer equal to null
		string *name = nullptr;
		//set goose pointer equal to null
		ExpressionNode* goose = nullptr;
		//set thenstate pointer equal to null
		StateNode* thenstate = nullptr;
		//set elsestate pointer equal to null
		StateNode* elsestate = nullptr;
		//call IfNode
		IfNode();

		//Destruct IfNode
		~IfNode();
		//printTo
		void printTo(ostream &os);
};

void IfNode::printTo(ostream& os) {
	//print if
	os << "If "; 
	//if goose is not null
	if(goose !=nullptr)
	{
		//print goose
		os << *goose << endl;
	}
	//if thenstate is not null
	if(thenstate != nullptr)
	{
		//print true statement message, thenstate pointer and %%% line
		os <<  "%%%%%%%% True Statement %%%%%%%%" << endl << *thenstate << endl;
		os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";
	}
	//if elsestate is not null
    if (elsestate != nullptr)
    {
		//print a newline
		cout << endl;
		//print false statement message followed by elsestate followed by %%% line
        os << "%%%%%%%% False Statement %%%%%%%%" << endl << *elsestate << endl;
		os << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";
    }
}

IfNode::IfNode() {
	//set name equal to the string function
	name = new string();
	//set goose equal to ExpressionNode
	goose = new ExpressionNode;
}

IfNode::~IfNode() {
	//print delete an if node
	cout << "Deleting an ifNode" << endl;
	//delete goose
	delete goose;
	//set goose to null
	goose = nullptr;
	//delete thenstate
	delete thenstate;
	//set thensatte to null
	thenstate = nullptr;
	//delete elsestate
	delete elsestate;
	//set elsetate to null
	elsestate = nullptr;
}
//*****************************************************************************
class WhileNode: public StateNode
{
	public:
		//set name pointer to null
		string *name = nullptr;
		//set expression pointer to null
		ExpressionNode* expression = nullptr;
		//set loop pointer to null
		StateNode* loop = nullptr;
		//call WhielNode
		WhileNode();

		//Destruct WhileNode
		~WhileNode();
		//printTo
		void printTo(ostream &os);
};

WhileNode::WhileNode() {
	//set name equal to string function
	name = new string();
	//set expression equal to ExpressionNode
	expression = new ExpressionNode;
}

void WhileNode::printTo(ostream& os) {
	//print While followed by expression
	os << "While " << *expression <<endl
	//print loop body
	<< "%%%%%%%% Loop Body %%%%%%%%"  << endl
	//print the loop
	<< *loop << endl << "%%%%%%%%%%%%%%%%%%%%%%%%%%%";
}

WhileNode::~WhileNode()
{
	//print delete while node
    cout << "Deleting a whileNode" << endl;
	//delete name
    delete name;
	//delete epression
    delete expression;
	//set expression equal to pointer
    expression = nullptr;
	//delete loop
    delete loop;
	//set loop equal to null
    loop = nullptr;
}


//*****************************************************************************
// class IdNode (Identifier Node)
class IdNode : public FactorNode {
public:
	//set name pointer equal to null
    string *name = nullptr;
	//call IdNode
    IdNode(string id);

	//Destruct IDNode
    ~IdNode();
	//printTo
    void printTo(ostream & os);
};

IdNode::IdNode(string id) {
	//set name equal to string taking in id
	name = new string(id);
}

void IdNode::printTo(ostream& os) {
	//print factor followed by the id
	os << " factor( " << *name << " )";
}

IdNode::~IdNode() {
	//print deleting fctor node
	cout << "Deleting a factorNode" << endl;
	//delete name
	delete name;
	//set name equal to null
	name = nullptr;
}
//*****************************************************************************
// class NotNode
class NotNode : public FactorNode {
public:
	//set factorPtr equal to null
	FactorNode *factorPtr = nullptr;
	//call NotNode
    NotNode(FactorNode* en);
	//set NOp equal to the not token 
	int NOp = 3010;

	//Destruct NotNode
	~NotNode();
	//printTo
	void printTo(ostream & os);
};

NotNode::NotNode(FactorNode *en) {
	//set factorPtr to en
	factorPtr = en;
}

void NotNode::printTo(ostream& os) {
	//print out factor followed by the minus symbol and the factorPtr pointer
	os << " factor(" << token_to_string(NOp) << *factorPtr << " )";
}

NotNode::~NotNode() {
	//print deleting factor node
	cout << "Deleting a factorNode" << endl;
	//delete factorPtr
    delete factorPtr;
	//set factorPtre to null
    factorPtr = nullptr;
}
//*****************************************************************************
// class MinusNode
class MinusNode : public FactorNode {
public:
	//set factorPtr equal to null
	FactorNode *factorPtr = nullptr;
	//call MinusNode
    MinusNode(FactorNode* en);
	//set MOp equal to the minus token
	int MOp = 3001;

	//Destruct MinusNode
	~MinusNode();
	//printTo
	void printTo(ostream & os);
};

MinusNode::MinusNode(FactorNode *en) {
	//set factorPtr equal to en
	factorPtr = en;
}

void MinusNode::printTo(ostream& os) {
	//print out factor followed by the minus symbol followed by factorPtr
	os << " factor( " << token_to_string(MOp) << *factorPtr << " )";
}

MinusNode::~MinusNode() {
	//print deleting factor node
	cout << "Deleting a factorNode" << endl;
	//delete factorPtr
	delete factorPtr;
	//set factorPtr to null
	factorPtr = nullptr;
}
//*****************************************************************************
// class IntLitNode (Integer Literal Node)
class IntLitNode : public FactorNode {
public:
	//set int_literal to zero
    int int_literal = 0;
	//call int lit node
    IntLitNode(int value);
	//Destruct int lit node
    ~IntLitNode();
	//printTo
    void printTo(ostream & os);
};

IntLitNode::IntLitNode(int value) {
	//set int literal to value
	int_literal = value;
}

IntLitNode::~IntLitNode() {
	//print deleting a factor node
	cout << "Deleting a factorNode" << endl;
}

void IntLitNode::printTo(ostream& os) {
	//print factor followed by the integer literal
	os  << " factor( " <<  int_literal << " )";
}

//*****************************************************************************
// class FloatLitNode (Float Literal Node)
class FloatLitNode : public FactorNode {
public:
	//set float_literal equal to zero
    float float_literal = 0.0;
	//call float lit node
    FloatLitNode(float value);
	//Destruct float lit node
    ~FloatLitNode();
	//printTo
    void printTo(ostream & os) override;
};

FloatLitNode::FloatLitNode(float value) {
	//set float lit node equal to value
	float_literal = value;
}

FloatLitNode::~FloatLitNode() {
	//print deleting a factor node
	cout << "Deleting a factorNode" << endl;
}

void FloatLitNode::printTo(ostream& os) {
	//print out factor folloed by the float literal
	os << " factor( " << float_literal << " )";
}
//*****************************************************************************
// class StringLitNode
class StringLitNode
{
public:
	//set mystring pointer equal to null
    string *mystring = nullptr;
	//call string lit node
    StringLitNode(string mystring);
	//destruct string lit node
    ~StringLitNode();
};

ostream &operator<<(ostream &os, StringLitNode &node)
{
	//print the string
    os << *(node.mystring);
	//return
    return os;
}

StringLitNode::StringLitNode(string s) {
	//set mystring equal to new string s
	mystring = new string(s);
}

StringLitNode::~StringLitNode() {
	//delete mystring
	delete mystring;
}
//*****************************************************************************
class WriteNode: public StateNode
{
	public:
	//set idTerm pointer equal to null
	FactorNode *idTerm = nullptr;
	//set string lit term equal to null
	StringLitNode *stringLitTerm = nullptr;
	//set id lit term equal to null
	StringLitNode *idlitTerm = nullptr;
	//set name equal to null
	string* name = nullptr;
	//call writeNode
	WriteNode();

	//destruct WriteNode
	~WriteNode();
	//printTo
	void printTo(ostream& os);
};

void WriteNode::printTo(ostream &os)
{
	//print Write
    os << "Write ";
	//if the identifier literal is not null
    if (idlitTerm != nullptr)
    {
		//print Value followed by idlitTerm
        os << "Value " << *idlitTerm;
    }
	//if the string literal is not null
    if (stringLitTerm != nullptr)
    {
		//print String followed by stringLitTerm
        os << "String " << *stringLitTerm;
    }
}

WriteNode::WriteNode()
{
	//set name equal to string function
    name = new string();
}

WriteNode::~WriteNode() {
	//print deleting WriteNode
	cout << "Deleting a writeNode" << endl;
	//delete name
    delete name;
	//delete stringLitTerm
    delete stringLitTerm;
	//set stringLitTerm equal to null
    stringLitTerm = nullptr;
	//delete idTerm
    delete idTerm;
	//set idTerm to null
    idTerm = nullptr;
	//delete idLitTerm
	delete idlitTerm;
	//set IdLitTerm to null
	idlitTerm = nullptr;
}

ProgNode::~ProgNode() {
	//print deleting a program node
	cout << "Deleting a programNode" << endl;
	//delete name
	delete name;
	//delete block
	delete block;
}
BlockNode::~BlockNode()
{
	//print deleting a block node
    cout << "Deleting a blockNode" << endl;
	//set length to the statements in size
    int length = statements->size();
	//for loop
    for (int i = 0; i < length; ++i)
    {
		//delete statements at i
        delete statements->at(i);
		//set statements to null
        statements->at(i) = nullptr;
    }

	//set another length variable to size of var
    int length2 = var->size();
	//for loop
    for (int j = 0; j < length2; ++j)
    {
		//delete var at j
        delete var->at(j);
    }
}

// Uses double dispatch to call the overloaded method printTo in the 
// FactorNodes: IdNode, IntLitNode, and NestedExprNode
ostream& operator<<(ostream& os, FactorNode& fn) {
	fn.printTo(os);
	return os;
};

//Destruct FactorNode
FactorNode::~FactorNode() {}

#endif /* PARSE_TREE_NODES_H */
