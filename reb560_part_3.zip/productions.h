/******************************************************************* 
Name: Raleigh Bumpers             NetID: reb560
  Course: CSE 4714              
  Project: Part 3 - Parse Tree
  Purpose of File: Contains the program parse tree code for program 3.
*******************************************************************/

#ifndef PRODUCTIONS_H
#define PRODUCTIONS_H

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include "parse_tree_nodes.h"
#include "lexer.h"


extern set<string> symbolTable;
int nextToken = 0;  // token returned from yylex
int level = 0;  // used to indent output to approximate parse tree*/


extern "C"
{
	// Instantiate global variables used by flex
    extern FILE *yyin;         // input stream
	extern char* yytext;       // text of current lexeme
	extern int   yylex();      // the generated lexical analyzer
}

// Forward declarations of production parsing functions
ProgNode *program();
ReadNode* read();
BlockNode* block();
WriteNode* write();
FactorNode* factor();
TermNode* term();
ExpressionNode *expression();
WhileNode* while_statement();
IfNode* if_statement();
StateNode* statement();
AssignNode* assignement();
CompNode* compound_statement();

// Forward declarations of functions that check whether the current token is
// in the first set of a production rule
bool first_of_block();
bool first_of_statement();

// Get the next lexeme (word in sentence)
int lex() {
  nextToken = yylex();
  if( nextToken == TOK_EOF ) {
    yytext[0] = 'E'; yytext[1] = 'O'; yytext[2] = 'F'; yytext[3] = 0;   
  }

  //printf("Next token: %d, lexeme: |%s|\n", nextToken, yytext);
  return nextToken;
}

inline void indent(){
    for (int i = 0; i<level; i++)
        std::cout << ("    ");
}

void output(){
    indent();
    std::cout << "-->found " << yytext << std::endl;
}

//*****************************************************************************
//functions that check the validity of the first of functions
bool first_of_block(void)
{
    return nextToken == TOK_VAR || nextToken == TOK_BEGIN;
}
bool first_of_statement(void)
{
    return nextToken == TOK_IDENT || nextToken == TOK_WHILE || nextToken == TOK_IF || nextToken == TOK_READ || nextToken == TOK_WRITE || nextToken == TOK_BEGIN;
}


//read function
ReadNode *read()
{
    //set newReadNode pointer to a new ReadNode
    ReadNode* newReadNode = new ReadNode;
    //if the first token does not match those in the first of read function
    if (nextToken != TOK_READ)
    {
        //throw an error
        throw "read error";
    }
    else {
    //call the indent function
    indent();
    //print the enter read message
    cout << "enter <read>" << endl;
    //indent the upcoming output
    ++level;
    }
    //if the next token is a read token
    if(nextToken == TOK_READ)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an identifier
    if(nextToken == TOK_IDENT)
    {
        //create a new string for name in ReadNode
        newReadNode->name = new string(yytext);
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a closed parenthese
    if(nextToken == TOK_CLOSEPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    } 
    //if the next token does not match any of the above lexemes in the correct order
    else {
        //print an error message and halt the program
        throw "999: an error has occured";
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit read function
    cout << "exit <read>" << endl;
    
    //return a new ReadNode
    return newReadNode;
}

//write 
WriteNode *write()
{
    //if the next token is 
    if (nextToken != TOK_WRITE)
        throw "134: illegal type of operand(s)";

    //call the indent function
    indent();
    //print the enter write message
    cout << "enter <write>" << endl;
    //indent the upcoming output
    ++level;

    //set newWriteNode pointer equal to a new WriteNode
    WriteNode *newWriteNode = new WriteNode;
    //create a new string for name in WriteNode
    newWriteNode->name = new string(yytext);

    //if the next token is a write token
    if(nextToken == TOK_WRITE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an identifier or a string literal
    if(nextToken == TOK_IDENT)
    {
        //output the lexeme
        output();
        //crete a new string of type identifier 
        newWriteNode->idlitTerm = new StringLitNode(string(yytext));
        //move to the next token
        lex();
    }
    //if the next token is a string literal
    if (nextToken == TOK_STRINGLIT)
    {
        //output the lexeme
        output();
        //create a new string of type string literal
        newWriteNode->stringLitTerm = new StringLitNode(string(yytext));
        //move to the next token
        lex();
    }
    //if the next token is a closed parenthese
    if(nextToken == TOK_CLOSEPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit write message
    cout << "exit <write>"<< endl;

    //return a new WriteNode
    return newWriteNode;
}

//factor function
FactorNode *factor()
{
    //set a new Factor node equal to null
    FactorNode *newFactorNode = nullptr;
    //if the next token is a minus symbol (it should always be followed by an integer or a float)
    if(nextToken == TOK_MINUS)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;
        //output the lexeme
        output();
        //move to the next token
        lex();
        //set a new factor node equal to a new minus node and call factor
        newFactorNode = new MinusNode(factor());

        //if the next token is an integer lieral
        if(nextToken == TOK_INTLIT)
        {
            //call the indent function
            indent();
            //print the enter factor message
            cout << "enter <factor>" << endl;
            //indent the upcoming output
            ++level;

            //output the lexeme
            output();
            //set the current integer literal equal to to newFactorNode
            newFactorNode = new IntLitNode(atoi(yytext));
            //move to the next token
            lex();
        }
        //if the next token is a floating point number
        else if(nextToken == TOK_FLOATLIT)
        {
            //call the indent function
            indent();
            //print the enter factor message
            cout << "enter <factor>" << endl;
            //indent the upcoming output
            ++level;

            //output the lexeme
            output();
            //set the current float literal equal to newFactorNode
            newFactorNode = new FloatLitNode(atof(yytext));
            //move to the next token
            lex();
        }

    }
    //if the next token is an integer literal (not after a minus)
    else if(nextToken == TOK_INTLIT)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //output the lexeme
        output();
        //set the current integer literal equal to newFactorNode
        newFactorNode = new IntLitNode(atoi(yytext));
        //move to the next token
        lex();
    }
    //if the next token is a floating point number
    else if(nextToken == TOK_FLOATLIT)
    {
        //call the indent function
        indent();
        //print the enter factor function
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //output the lexeme
        output();
        //set the current float literal equal to newFactorNode
        newFactorNode = new FloatLitNode(atof(yytext));
        //move to the next token
        lex();
    }
    //if the next token is an identifier
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter function message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //if the identifier is already in the set stmbol table
        if(symbolTable.find(yytext) == symbolTable.end() )
        {
            //print an error message and halt the program
            throw "104: identifier not declared";
        }
        //set the current identifier equal to newFactorNode
        newFactorNode = new IdNode(string(yytext));
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    else if(nextToken == TOK_OPENPAREN)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;
        //output the lexeme
        output();
        //move to the next token
        lex();

        //set nested expression equal to newFactorNode
        newFactorNode = new NestedExprNode(expression());
        
        //if the next token is a closed parenthese
        if(nextToken == TOK_CLOSEPAREN)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();
        }
    
    }
    //if the next token is a not token
    else if(nextToken == TOK_NOT)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //output the lexeme
        output();
        //move to the next token
        lex();

        //set a new factor node equal to a new not node and call factor
        newFactorNode = new NotNode(factor());
    }
    else{
        //print an error message and halt the program
        throw "THIS ONE 104: identifier not declared";
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit factor message
cout << "exit <factor>" << endl;

//return a new factor node
return newFactorNode;
}

//term function
TermNode* term()
{
    //cout << "cheese" << yytext << endl;
    TermNode *newTermNode = new TermNode;

    //check to make sure the next token is an acceptable one to start with
    if (nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || nextToken == TOK_NOT || nextToken == TOK_MINUS)
    {
    //call the indent function
    indent();
    //prints out the enter term message
    cout << "enter <term>" << endl;
    //indents the upcoming output
    ++level;
    
    //assign name in term node to the current token
    newTermNode->name = new string(yytext);
    //if the toekn is the first of a factor, call factor
    newTermNode->FirstFactor = factor();
    }
    //if the next token is not one accepted to start with, throw an error
    else {
        throw "error";
    }
    
    //while the next token is a multiplication symbol
    while(nextToken == TOK_MULTIPLY) {
        //output the lexeme
        output();
        //push the token into the vector in TermNode
        newTermNode->restFactorOps.push_back(nextToken);
        //move to the next token
        lex();
        //call factor
        newTermNode->restFactors.push_back(factor());
    }
    while(nextToken == TOK_DIVIDE) {
        //output the lexeme
        output();
        //push the token into the vector in TermNode
        newTermNode->restFactorOps.push_back(nextToken);
        //move to the next token
        lex();
        //call factor
        newTermNode->restFactors.push_back(factor());
    }
    while(nextToken == TOK_AND) {
        //output the lexeme
        output();
        //push the token into the vector in TermNode
        newTermNode->restFactorOps.push_back(nextToken);
        //move to the next token
        lex();
        //call factor
        newTermNode->restFactors.push_back(factor());
    }
    //while the next token is a multiplication symbol
    while(nextToken == TOK_MULTIPLY) {
        //output the lexeme
        output();
        //push the token into the vector in TermNode
        newTermNode->restFactorOps.push_back(nextToken);
        //move to the next token
        lex();
        //call factor
        newTermNode->restFactors.push_back(factor());
    }

//un-indents the upcoming output
--level;
//calls the indent function
indent();
//outputs the exit term message
cout << "exit <term>" << endl;

//return a new TermNode
return newTermNode;
}

//simple expression function
SimpleExpressionNode* simple_expr()
{
    //set newSimpleExprNode pointer equal to a new SimpleExpressionNode
    SimpleExpressionNode *newSimpleExprNode = new SimpleExpressionNode;
    //assign name in simple expression node to the current token
    newSimpleExprNode->name = new string(yytext);
    //check to see if the first token is an accepted one
    if (nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || nextToken == TOK_NOT || nextToken == TOK_MINUS)
    {
    //if the next token is an open parenthese
    //call the indent function
    indent();
    //print the enter simple expression message
    cout << "enter <simple expression>" << endl;
    //indents the upcoming output
    ++level;

    //parse the first term
    newSimpleExprNode->firstTerm = term();
    }

    //if the first token is not acceptable
    else {
        throw "simple expression error";
    }
    //while the next token is a plus "+" symbol
    while(nextToken == TOK_PLUS)
    {
        //output the lexeme
        output();
        //push the token into the vector in simple expression node
        newSimpleExprNode->termOps.push_back(nextToken);
        //move to the next token
        lex();
        //call term
        newSimpleExprNode->terms.push_back(term());
    }
    while(nextToken == TOK_MINUS)
    {
        //output the lexeme
        output();
        //push the token into the vector in simple expression node
        newSimpleExprNode->termOps.push_back(nextToken);
        //move to the next token
        lex();
        //call term
        newSimpleExprNode->terms.push_back(term());
    }
    while(nextToken == TOK_OR)
    {
        //output lexeme
        output();
        //push the token into the vector in simple expression node
        newSimpleExprNode->termOps.push_back(nextToken);
        //move to the next token
        lex();
        //call term
        newSimpleExprNode->terms.push_back(term());
    }
    
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit simple expression message
cout << "exit <simple expression>" << endl;

//return a new simple expression node
return newSimpleExprNode;
}

//expression function
ExpressionNode *expression()
{
    //set newExprNode pointer equal to new ExpressionNode
    ExpressionNode* newExprNode = new ExpressionNode;
    //check if the first token is accepted
    if (nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || nextToken == TOK_NOT || nextToken == TOK_MINUS)
    {
    //assign name in expression node to the current token
    newExprNode->name = new string(yytext);
    //call the indent function
    indent();
    //print the enter expression message
    cout << "enter <expression>" << endl;
    //indent the upcoming output
    ++level;

    //parse the first simple expression
    newExprNode->firstSimpleExpression = simple_expr();
    
    }
    //if the first token is not accepted throw an error
    else {
        throw "expression error";
    }
    //if the next token is an equal to, less than, greaterthan, or not equal symbol
    if(nextToken == TOK_EQUALTO || nextToken == TOK_LESSTHAN || nextToken == TOK_GREATERTHAN || nextToken == TOK_NOTEQUALTO)
    {
        //output the lexeme
        output();
        //push the token into the vector in expression
        newExprNode->restSimpleExpressionOps.push_back(nextToken);
        //move to the next token
        lex();
        //call simple expression
        newExprNode->restSimpleExpressions.push_back(simple_expr());
    }
    
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit expression message
cout << "exit <expression>" << endl;

//return a new expression node
return newExprNode;
}

//while statement function
WhileNode *while_statement()
{
    //set newWhileNode pointer equal to a new while node
    WhileNode *newWhileNode = new WhileNode;
    //if the next token is not a while token
    if(nextToken != TOK_WHILE)
        //print an error message and halt the program
        throw "999: an error has occured";

    //call the indent function
    indent();
    //print the enter while statement function
    cout << "enter <while statement>" << endl;
    //indent the upcoming output
    ++level;

    //assign name in while node to the current token
    newWhileNode->name = new string(yytext);

    //if the next token is a while token
    if(nextToken == TOK_WHILE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call expression
        newWhileNode->expression = expression();
        //call statement
        newWhileNode->loop = statement();
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit while statement function
    cout << "exit <while statement>"<< endl;

    //return a new while node
    return newWhileNode;
}

//if statement function
IfNode *if_statement()
{
    //set newIfNode pointer equal to a new if node
    IfNode *newIfNode = new IfNode;
    //if the next token is not if
    if (nextToken == TOK_IF)
    {
    //call the indent function
    indent();
    //print the enter if statement message
    cout << "enter <if statement>" << endl;
    //indent the upcoming output
    ++level;

    //create a string for name in if node
    newIfNode->name = new string(yytext);
    }

    //if the next token is not if throw an error
    else {
        throw "if error";
    }
    //if the next token is an if token
    if(nextToken == TOK_IF)
    {
        //output the lexeme
        output();
        //assign name in if node to the current token
        newIfNode->name = new string(yytext);
        //move to the next token
        lex();
        //call expression
        newIfNode->goose = expression();
    }
    //if the next token is a then token
    if(nextToken == TOK_THEN)
    {
        //output the lexeme
        output();
        //move to the next token 
        lex();
        //call statement
        newIfNode->thenstate = statement();
    }
    //if the next token does not match any of the lexemes in correct order
    else{
        //print an error message and halt the program
        throw "52: 'THEN' expected";
    }
    //if the next token is an else token
    if(nextToken == TOK_ELSE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call statement
        newIfNode->elsestate = statement();
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit if statement function
cout << "exit <if statement>"<< endl;

//return a new if node
return newIfNode;
}

//assignment function
AssignNode *assignment()
{
    //if the next token does not match any of those in the first of assignment function
    if(nextToken != TOK_IDENT)
        throw "ident error assign";
    //call the indent function
    indent();
    //print the enter assignment function
    cout << "enter <assignment>" << endl;
    //indent the upcoming output
    ++level;
    //if the identifier is not in the set symbol table 
    if(symbolTable.find(yytext) == symbolTable.end() )
    {
        //throw an error and halt the program
        throw "104: identifier not declared";
    }
    //set pointer newANode equal to new assignment node
    AssignNode* newANode = new AssignNode;
    //assign name in assignment node to the current token
    newANode->name = new string(yytext);
    //output the lexeme
    output();
    //move to the next token
    lex();

    //if the next token is an assignment operator
    if(nextToken != TOK_ASSIGN)
        throw "assign error";
    //set AOp equal to the next token
    newANode->AOp = nextToken;
    //output lexeme
    output();
    //move to the next token
    lex();
    //check if the next token is accepted
    if (nextToken == TOK_INTLIT || nextToken == TOK_FLOATLIT || nextToken == TOK_IDENT || nextToken == TOK_OPENPAREN || nextToken == TOK_NOT || nextToken == TOK_MINUS)
    {
        //call expression
        newANode->assignExpr = expression();
    }
    //if the next token is not accepted throw an error
    else {
        throw "assign expression error";
    }

//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit assignment function
cout << "exit <assignment>"<< endl;

//return a new assignment node
return newANode;
}

//statement function
StateNode *statement()
{
    //set newStateNode pointer equal to null
    StateNode *newStateNode = nullptr;
    //if the next token is a begin token
    if(nextToken == TOK_BEGIN)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent upcoming output
        ++level;

        //call the compound statement function
        newStateNode = compound_statement();
    }
    //if the next token is an identifier token
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the assignment function
        newStateNode = assignment();
    }
    //if the next token is an if token
    else if(nextToken == TOK_IF)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the if statement function
        newStateNode = if_statement();
    }
    //if the next token is a while token
    else if(nextToken == TOK_WHILE)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call while statement function
        newStateNode = while_statement();
    }
    //if the next token is a read token
    else if(nextToken == TOK_READ)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the read function
        newStateNode = read();
    }
    //if the next token is a write token
    else if(nextToken == TOK_WRITE)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming ouput
        ++level;

        //call the write function
        newStateNode = write();
    }
    //if the next token does not match any of the next tokens in the correct order
    else
    {
        //print an error message and halt the program
        throw "900: illegal type of statement";
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit statement message
cout << "exit <statement>" << endl; 

//return a new statement node
return newStateNode;
}

//compound statement function
CompNode *compound_statement()
{
    
    //if the next token is not in the first of compound statement function
    if (nextToken != TOK_BEGIN)
        throw "begin error";
    //call the indent function
    indent();
    //print the enter compound statement message
    cout << "enter <compound_statement>" << endl;
    //indent the upcoming output
    ++level;

    //output the lexeme
    output();
    //set newCompNode pointer equal to new CompNode
    CompNode *newCompNode = new CompNode;
    //move to the next token
    lex();
    //assign name in compound node to the current token
    newCompNode->name = new string(yytext);


    //if the next token is not in first_of_statement throw an error
    if(!first_of_statement())
        throw "COMPOUND ERROR";
        
    //call statement
    newCompNode->firstStatement = statement();
                
        //while the next token is a semicolon
        while(nextToken == TOK_SEMICOLON)
        {
            //output lexeme
            output();
            //move to the next token
            lex();
            //call statement
            newCompNode->Statements->push_back(statement());
        }
        //if the next token is an end token
        if(nextToken == TOK_END)
        {
            //output lexeme
            output();
            //move to the next token
            lex();
        }
    
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit compound statement message
cout << "exit <compound_statement>"<< endl;

//return a new compund statement node
return newCompNode;
}


//block function
BlockNode *block()
{
    //if the next token does not match any of those in the first of block function
    if (!first_of_block())
        //print an error message and halt the program
        throw "18: error in declaration part OR 17: 'BEGIN' expected";

    //set the newBlockNode pointer equal to new BlockNode
    BlockNode *newBlockNode = new BlockNode;
    //call the indent function
    indent();
    //print the enter block message
    cout << "enter <block>" << endl;
    //indent the upcoming output
    ++level;
    
    //if the next token is a veriable token
    if(nextToken == TOK_VAR)
    {
        //ouput the lexeme
        output();
        //move to the next token
        lex();

        //if the next token is an identifier
        if(nextToken == TOK_IDENT)
        {
            //if the identifier is not in the set symbol table 
            if(symbolTable.find(yytext) == symbolTable.end() )
            {
                //add the identifier to the set symbol table
                symbolTable.insert(yytext);
            }
            //if the identifier is already in the set symbol table
            else{
                //print an error message and halt the program
                throw "101: identifier not declared";
            }
            //push the current token into the vector in block node
            newBlockNode->var->push_back(new string(yytext));
            //output the lexeme
            output();
            //move to the next token
            lex();
            
            //if the next token is a colon
            if(nextToken == TOK_COLON)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is an integer or a real value
            if(nextToken == TOK_INTEGER || nextToken == TOK_REAL)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is a semicolon
            if(nextToken == TOK_SEMICOLON)
            {
                //output the lexeme
                output();
                //output a new line
                cout << endl;
                //move to the next 
                lex();
                //whiel the next token is not begin
                while(nextToken != TOK_BEGIN)
                {
                    //if the next token is not an identifier throw an error
                    if(nextToken != TOK_IDENT)
        throw "BIG ERROR";
    //if the identifier is alreadt in the set symbol table
    if(symbolTable.find(yytext) == symbolTable.end() )
    {
        //add the identifier to the set symbol table
        symbolTable.insert(yytext);
    }
    //if the identifier is already in the set symbol table
    else{
        //print an error message and halt the program
        throw "101: identifier declared twice";
    }
    //push the current token into the vector in block node
    newBlockNode->var->push_back(new string(yytext));
    //oouput the lexeme
    output();
    //move to the next token 
    lex();
    //if the next token is a colon
    if(nextToken == TOK_COLON)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an integer or a real value
    if(nextToken == TOK_INTEGER || nextToken == TOK_REAL)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a semicolon
    if(nextToken == TOK_SEMICOLON)
    {
        //output the lexeme
        output();
        //output a new line
        cout << endl;
        //move to the next token
        lex();
        
    }
                }
            }
        }
    }

    //call compund statement
    newBlockNode->statements->push_back(compound_statement());
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit block message
    cout << "exit <block>" << endl;

    //return a new block node
    return newBlockNode;
}
    


//program function (called first)
ProgNode *program() {

    //condition that checks if the first of program function is legal
    if (nextToken == TOK_PROGRAM) // Check for PROGRAM
    {
 
        //begins the program function
        //calls the indent function
        indent();
        //outputs the entrance of program message
        cout << "enter <program>" << endl;
        //indents the upcoming output
        ++level;


        //output the token
        output();
        //move to the next token
        lex();
    }
    //if the first token is not a TOK_PROGRAM throw an error
    else {
        throw "program error";
    }
    //condition for if the next token in the file is a match for TOK_IDENT
    if(nextToken != TOK_IDENT)
    {
        throw "ident error";
    }
    //output the lexeme
    output();
    //create a string and set it to the current token
    string *progName = new string(yytext);
    //move to the next token
    lex();
    //condition for if the next token in the file is a match for TOK_SEMICOLON
    if(nextToken == TOK_SEMICOLON)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }

    //calls the block function
    BlockNode *newBlockNode = block();
    
    //un-indents the upcoming output
   --level;
   //calls the indent function
    indent();
    //prints out the end of program message
    cout << "exit <program>" << endl;
    //move to the next token
    lex();

    //return a new program node with the program name and a new block node
    return new ProgNode(*progName, newBlockNode);
}

#endif
