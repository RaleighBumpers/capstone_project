Driver does the same thing it was supposed to do in the example file.

Lexer is the same as it's been since part 1.

Makefile is the same with the appropriate updates for part 3.

parse_tree_nodes contains all operations for classes.

productions is the same as part 2 except has code to create the nodes of the parse tree as well.

rules is the same as it's been since part 1.