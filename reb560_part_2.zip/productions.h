/******************************************************************* 
Name: Raleigh Bumpers             NetID: reb560
  Course: CSE 4714              
  Project: Part 2 - Parser
  Purpose of File: Contains the program parsing code for project part 2.
*******************************************************************/

#ifndef PRODUCTIONS_H
#define PRODUCTIONS_H

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

extern set<string> symbolTable;
int nextToken = 0;  // token returned from yylex
int level = 0;  // used to indent output to approximate parse tree


extern "C"
{
	// Instantiate global variables used by flex
	extern char* yytext;       // text of current lexeme
	extern int   yylex();      // the generated lexical analyzer
}

// Forward declarations of production parsing functions
void program();
void read();
void block();
void write();
void factor();
void term();
void simple_expr();
void expression();
void while_statement();
void if_statement();
void statement();
void assignment();

// Forward declarations of functions that check whether the current token is
// in the first set of a production rule
bool first_of_program();
bool first_of_block();
bool first_of_assignment();
bool first_of_com_statement();
bool first_of_if();
bool first_of_read();



// Get the next lexeme (word in sentence)
int lex() {
  nextToken = yylex();
  if( nextToken == TOK_EOF ) {
    yytext[0] = 'E'; yytext[1] = 'O'; yytext[2] = 'F'; yytext[3] = 0;   
  }

  //printf("Next token: %d, lexeme: |%s|\n", nextToken, yytext);
  return nextToken;
}

inline void indent(){
    for (int i = 0; i<level; i++)
        cout << ("    ");
}

void output(){
    indent();
    cout << "-->found " << yytext << endl;
}

//*****************************************************************************
//functions that check the validity of the first of functions
bool first_of_program(void) {
    return nextToken == TOK_PROGRAM;
}
bool first_of_block(void)
{
    return nextToken == TOK_VAR || nextToken == TOK_BEGIN;
}
bool first_of_assignment(void)
{
    return nextToken == TOK_IDENT;
}
bool first_of_com_statement(void)
{
    return nextToken == TOK_BEGIN;
}
bool first_of_if(void)
{
    return nextToken == TOK_IF;
}
bool first_of_read(void)
{
    return nextToken == TOK_READ;
}

//program function (called first)
void program() {

    //condition that checks if the first of program function is legal
    if (!first_of_program()) // Check for PROGRAM
        //print an error message and halt the program
        throw "3: 'PROGRAM' expected";
    
    //begins the program function
    //calls the indent function
    indent();
    //outputs the entrance of program message
    cout << "enter <program>" << endl;
    //indents the upcoming output
    ++level;
    
    //condition for if the next token in the file is a match for TOK_PROGRAM
    if(nextToken == TOK_PROGRAM)
    {
        //output the token
        output();
        //move to the next token
        lex();
    }
    //condition for if the next token in the file is a match for TOK_IDENT
    if(nextToken == TOK_IDENT)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //condition for if the next token in the file is a match for TOK_SEMICOLON
    if(nextToken == TOK_SEMICOLON)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //calls the block function
    block();
    
    //un-indents the upcoming output
   --level;
   //calls the indent function
    indent();
    //prints out the end of program message
    cout << "exit <program>" << endl;
     
}

//term function
void term()
{
    //condition for if the next token in the file is a match for TOK_OPENPAREN
    if(nextToken == TOK_OPENPAREN)
    {
        //call the indent function
        indent();
        //prints out the enter term message
        cout << "enter <term>" << endl;
        //indents the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    else if(nextToken == TOK_NOT)
    {
        //call the indent function
        indent();
        //print the enter term message
        cout << "enter <term>" << endl;
        //indent the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    //if the next token is a minus token
    else if(nextToken == TOK_MINUS)
    {
        //call the indent function
        indent();
        //print the enter term message
        cout << "enter <term>" << endl;
        //indent the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    //if the next token is an integer literal
    else if(nextToken == TOK_INTLIT)
    {
        //call the indent function
        indent();
        //print the enter term message
        cout << "enter <term>" << endl;
        //indent the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    //if the next token is a floating point number
    else if(nextToken == TOK_FLOATLIT)
    {
        //call the indent function
        indent();
        //print the enter term message
        cout << "enter <term>" << endl;
        //indent the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    //if the next token is an identifier
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter term message
        cout << "enter <term>" << endl;
        //indent the upcoming output
        ++level;

        //call the factor function
        factor();
    }
    //if the next token does not match any of the above lexemes in the correct order
    else{
        //print an error message and halt the program
        throw "902: illegal type of term";
    }
    //while the next token is a multiplication symbol
    while(nextToken == TOK_MULTIPLY)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the factor function
        factor();
    }
    //while the next token is a division symbol
    while(nextToken == TOK_DIVIDE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the factor function
        factor();
    }
    //while the next token is an and symbol
    while(nextToken == TOK_AND)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the factor function
        factor();
    }
//un-indents the upcoming output
--level;
//calls the indent function
indent();
//outputs the exit term message
cout << "exit <term>" << endl;
}

//simple expression function
void simple_expr()
{
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //call the indent function
        indent();
        //print the enter simple expression message
        cout << "enter <simple expression>" << endl;
        //indents the upcoming output
        ++level;

        //call term function
        term();
    }
    //if the next token is a not symbol
    else if(nextToken == TOK_NOT)
    {
        //call the indent function
        indent();
        //print the enter simple expression function
        cout << "enter <simple expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the term function
        term();
    }
    //if the next token is a minus symbol
    else if(nextToken == TOK_MINUS)
    {
        //call the indent function
        indent();
        //print the enter simple expression message
        cout << "enter <simple expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the term function
        term();
    }
    //if the next token is an integer literal
    else if(nextToken == TOK_INTLIT)
    {
        //call the indent function
        indent();
        //print the simple expression message
        cout << "enter <simple expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the term function
        term();
    }
    //if the next token is a floating point number
    else if(nextToken == TOK_FLOATLIT)
    {
        //call the indent function
        indent();
        //print the enter simple expression message
        cout << "enter <simple expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the term function
        term();
    }
    //if the next token is an identifier
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter simple expression message
        cout << "enter <simple expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the term function
        term();

    }
    //if the next token is not a match for any of the above lexemes
    else 
    {
        //throw an error message and halt the program
        throw "901: illegal type of simple expression";
    }

    //while the next token is a plus "+" symbol
    while(nextToken == TOK_PLUS)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the term function
        term();
    }
    //while the next token is a minus "-" symbol
    while(nextToken == TOK_MINUS)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the term function
        term();
    }
    //while the next token is an or lexeme
    while(nextToken == TOK_OR)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the term function
        term();
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit simple expression message
cout << "exit <simple expression>" << endl;
}

//expression function
void expression()
{
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //call the indent function
        indent();
        //print the enter expression message
        cout << "enter <expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the simple expression function
        simple_expr();
    }
    //if the next token is a not symbol
    else if(nextToken == TOK_NOT)
    {
        //call the indent function
        indent();
        //print the enter expression message
        cout << "enter <expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the simple expression function
        simple_expr();
    }
    //if the next token is a minus symbol
    else if(nextToken == TOK_MINUS)
    {
        //call the indent function
        indent();
        //print the enter expression function
        cout << "enter <expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the simple expression function
        simple_expr();
    }
    //if the next token is an integer literal
    else if(nextToken == TOK_INTLIT)
    {
        //call the indent function
        indent();
        //print the enter expression message
        cout << "enter <expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the simple expression function
        simple_expr();
    }
    //if the next token is a floating point number
    else if(nextToken == TOK_FLOATLIT)
    {
        //call the indent function
        indent();
        //print the enter expression message
        cout << "enter <expression>" << endl;
        //indent the upcoming otput
        ++level;

        //call the simple expression function
        simple_expr();
    }
    //if the next token is an identifier
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter expression message
        cout << "enter <expression>" << endl;
        //indent the upcoming output
        ++level;

        //call the simple expression function
        simple_expr();

    }
    //if the next token does not match any of the above lexemes in correct order
    else{
        //throw an error message and halt the program
        throw "144: illegal type of expression";
    }
    //if the next token is an equal to symbol
    if(nextToken == TOK_EQUALTO)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the simple expression function
        simple_expr();
    }
    //if the next token is a less than symbol
    if(nextToken == TOK_LESSTHAN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the simple expression function
        simple_expr();
    }
    //if the next token is a greater than symbol
    if(nextToken == TOK_GREATERTHAN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the simple expression function
        simple_expr();
    }
    //if the next token is a not equal to symbol
    if(nextToken == TOK_NOTEQUALTO)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the simple expression function
        simple_expr();
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit expression message
cout << "exit <expression>" << endl;
}

//read function
void read()
{
    //if the first token does not match those in the first of read function
    if (!first_of_read())
        //print an error message and halt the program
        throw "134: illegal type of operand(s)";

    //call the indent function
    indent();
    //print the enter read message
    cout << "enter <read>" << endl;
    //indent the upcoming output
    ++level;

    //if the next token is a read token
    if(nextToken == TOK_READ)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an identifier
    if(nextToken == TOK_IDENT)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a closed parenthese
    if(nextToken == TOK_CLOSEPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();   
    } 
    //if the next token does not match any of the above lexemes in the correct order
    else {
        //print an error message and halt the program
        throw "999: an error has occured";
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit read function
    cout << "exit <read>" << endl;
    
}

//write function
void write()
{
    //if the next token is 
    if (nextToken != TOK_WRITE)
        throw "134: illegal type of operand(s)";

    //call the indent function
    indent();
    //print the enter write message
    cout << "enter <write>" << endl;
    //indent the upcoming output
    ++level;

    //if the next token is a write token
    if(nextToken == TOK_WRITE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    if(nextToken == TOK_OPENPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an identifier or a string literal
    if(nextToken == TOK_IDENT || nextToken == TOK_STRINGLIT)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a closed parenthese
    if(nextToken == TOK_CLOSEPAREN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit write message
    cout << "exit <write>"<< endl;
}

//while statement function
void while_statement()
{
    //if the next token is not a while token
    if(nextToken != TOK_WHILE)
        //print an error message and halt the program
        throw "999: an error has occured";

    //call the indent function
    indent();
    //print the enter while statement function
    cout << "enter <while statement>" << endl;
    //indent the upcoming output
    ++level;

    //if the next token is a while token
    if(nextToken == TOK_WHILE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the expression function
        expression();
        //call the statement function
        statement();
    }
    //un-indent the upcoming output
    --level;
    //call the indent function
    indent();
    //print the exit while statement function
    cout << "exit <while statement>"<< endl;
}

//if statement function
void if_statement()
{
    //if the next token is not in the first of if function
    if (!first_of_if())
        //print an error message and halt the program
        throw "3: 'if' expected";
    
    //call the indent function
    indent();
    //print the enter if statement message
    cout << "enter <if statement>" << endl;
    //indent the upcoming output
    ++level;

    //if the next token is an if token
    if(nextToken == TOK_IF)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the expression function
        expression();

    }
    //if the next token is a then token
    if(nextToken == TOK_THEN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the statement function
        statement();
    }
    //if the next token does not match any of the lexemes in correct order
    else{
        //print an error message and halt the program
        throw "52: 'THEN' expected";
    }
    //if the next token is an else token
    if(nextToken == TOK_ELSE)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the statement function
        statement();
    }
    //if next token does not match else token
    else{
        //un-indent the upcoming output
        --level;
        //call the indent function
        indent();
        //print the exit if statement message
        cout << "exit <if statement>"<< endl;
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit if statement function
cout << "exit <if statement>"<< endl;
}

//compound statement function
void compound_statement()
{
    //if the next token is not in the first of compound statement function
    if (!first_of_com_statement())
        //print an error message and halt the program
        throw "17: 'BEGIN' expected";

    //call the indent function
    indent();
    //print the enter compound statement message
    cout << "enter <compound_statement>" << endl;
    //indent the upcoming output
    ++level;

        //if the next token is a begin token
        if(nextToken == TOK_BEGIN)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();
            //call the statement function
            statement();
                
        }
        //if the next token is a semicolon
        if(nextToken == TOK_SEMICOLON)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();
            //call the statement function
            statement();
        }
        //while the next token is a semicolon
        while(nextToken == TOK_SEMICOLON)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();
            //call the statement function
            statement();
        }
        //if the next token is an end token
        if(nextToken == TOK_END)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();      
        }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit compound statement message
cout << "exit <compound_statement>"<< endl;
}

//assiignment function
void assignment()
{
    //if the next token does not match any of those in the first of assignment function
    if(!first_of_assignment())
        //print an error message and halt the program
        throw "2: identifier expected";

    //call the indent function
    indent();
    //print the enter assignment function
    cout << "enter <assignment>" << endl;
    //indent the upcoming output
    ++level;

    //if the next token is an identifier
    if(nextToken == TOK_IDENT)
    {
        //output the lexeme
        output(); 
    }
    //move to the next token
    lex();
    //if the next token is an assignment operator
    if(nextToken == TOK_ASSIGN)
    {
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the expression function
        expression();
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit assignment function
cout << "exit <assignment>"<< endl;
}

//statement function
void statement()
{
    //if the next token is a begin token
    if(nextToken == TOK_BEGIN)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent upcoming output
        ++level;

        //call the compound statement function
        compound_statement();
    }
    //if the next token is an identifier token
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the assignment function
        assignment();
    }
    //if the next token is an if token
    else if(nextToken == TOK_IF)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the if statement function
        if_statement();
    }
    //if the next token is a while token
    else if(nextToken == TOK_WHILE)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call while statement function
        while_statement();
    }
    //if the next token is a read token
    else if(nextToken == TOK_READ)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming output
        ++level;

        //call the read function
        read();
    }
    //if the next token is a write token
    else if(nextToken == TOK_WRITE)
    {
        //call the indent function
        indent();
        //print the enter statement message
        cout << "enter <statement>" << endl;
        //indent the upcoming ouput
        ++level;

        //call the write function
        write();
    }
    //if the next token does not match any of the next tokens in the correct order
    else
    {
        //print an error message and halt the program
        throw "900: illegal type of statement";
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit statement message
cout << "exit <statement>" << endl;  
}

//block function
void block()
{
    //if the next token does not match any of those in the first of block function
    if (!first_of_block())
        //print an error message and halt the program
        throw "18: error in declaration part OR 17: 'BEGIN' expected";
    
    //call the indent function
    indent();
    //print the enter block message
    cout << "enter <block>" << endl;
    //indent the upcoming output
    ++level;
    
    //if the next token is a veriable token
    if(nextToken == TOK_VAR)
    {
        //ouput the lexeme
        output();
        //move to the next token
        lex();

        //if the next token is an identifier
        if(nextToken == TOK_IDENT)
        {
            //if the identifier is not in the set symbol table 
            if(symbolTable.find(yytext) == symbolTable.end() )
            {
                //add the identifier to the set symbol table
                symbolTable.insert(yytext);
            }
            //if the identifier is already in the set symbol table
            else{
                //print an error message and halt the program
                throw "101: identifier not declared";
            }
            //output the lexeme
            output();
            //move to the next token
            lex();
            
            //if the next token is a colon
            if(nextToken == TOK_COLON)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is an integer or a real value
            if(nextToken == TOK_INTEGER || nextToken == TOK_REAL)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is a semicolon
            if(nextToken == TOK_SEMICOLON)
            {
                //output the lexeme
                output();
                //output a new line
                cout << endl;
                //move to the next 
                lex();
            }
        }
        //if the next tokn is an identifier
        while(nextToken == TOK_IDENT)
        {
            //if the identifier is alreadt in the set symbol table
            if(symbolTable.find(yytext) == symbolTable.end() )
            {
                //add the identifier to the set symbol table
                symbolTable.insert(yytext);
            }
            //if the identifier is already in the set symbol table
            else{
                //print an error message and halt the program
                throw "101: identifier declared twice";
            }
            //oouput the lexeme
            output();
            //move to the next token 
            lex();
            //if the next token is a colon
            if(nextToken == TOK_COLON)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is an integer or a real value
            if(nextToken == TOK_INTEGER || nextToken == TOK_REAL)
            {
                //output the lexeme
                output();
                //move to the next token
                lex();
            }
            //if the next token is a semicolon
            if(nextToken == TOK_SEMICOLON)
            {
                //output the lexeme
                output();
                //output a new line
                cout << endl;
                //move to the next token
                lex();
            }
        }
    
        //call the compund statement function
        compound_statement();
        //un-indent the upcoming output
        --level;
        //call the indent function
        indent();
        //print the exit block message
        cout << "exit <block>" << endl;

    }
    //if the statement starts with begin token
    else{
        //call the compund statement function
        compound_statement();
        //un-indent the upcoming output
        --level;
        //call the indent function
        indent();
        //print the exit block message
        cout << "exit <block>" << endl;
    }
}

//factor function
void factor()
{
    //if the next token is a minus symbol (it should always be followed by an integer or a float)
    if(nextToken == TOK_MINUS)
    {
        indent();
        cout << "enter <factor>" << endl;
        ++level;
        //output the lexeme
        output();
        //move to the next token
        lex();

        factor();
        //if the next token is an integer lieral
        if(nextToken == TOK_INTLIT)
        {
            //call the indent function
            indent();
            //print the enter factor message
            cout << "enter <factor>" << endl;
            //indent the upcoming output
            ++level;

            //output the lexeme
            output();
            //move to the next token
            lex();
        }
        //if the next token is a floating point number
        else if(nextToken == TOK_FLOATLIT)
        {
            //call the indent function
            indent();
            //print the enter factor message
            cout << "enter <factor>" << endl;
            //indent the upcoming output
            ++level;

            //output the lexeme
            output();
            //move to the next token
            lex();
        }

    }
    //if the next token is an integer literal (not after a minus)
    else if(nextToken == TOK_INTLIT)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a floating point number
    else if(nextToken == TOK_FLOATLIT)
    {
        //call the indent function
        indent();
        //print the enter factor function
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an identifier
    else if(nextToken == TOK_IDENT)
    {
        //call the indent function
        indent();
        //print the enter function message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //if the identifier is already in the set stmbol table
        if(symbolTable.find(yytext) == symbolTable.end() )
        {
            //print an error message and halt the program
            throw "104: identifier not declared";
        }
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is an open parenthese
    else if(nextToken == TOK_OPENPAREN)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;
        
        //output the lexeme
        output();
        //move to the next token
        lex();
        //call the expression function
        expression();
        //if the next token is a closed parenthese
        if(nextToken == TOK_CLOSEPAREN)
        {
            //output the lexeme
            output();
            //move to the next token
            lex();
        }
    
    }
    //if the next token is a not token
    else if(nextToken == TOK_NOT)
    {
        //call the indent function
        indent();
        //print the enter factor message
        cout << "enter <factor>" << endl;
        //indent the upcoming output
        ++level;

        //call factor recursively
        factor();
        //output the lexeme
        output();
        //move to the next token
        lex();
    }
    //if the next token is a begin token
    else if(nextToken == TOK_BEGIN)
    {
        //call compund statement function
        compound_statement();
    }
    //if the next token does not match any of the lexemes in correct order
    else{
        //print an error message and halt the program
        throw "104: identifier not declared";
    }
//un-indent the upcoming output
--level;
//call the indent function
indent();
//print the exit factor message
cout << "exit <factor>" << endl;
}

#endif
